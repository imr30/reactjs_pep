//write a program that prints all the even numbers from 1 to 20 using a for loop
for (var i=1; i<=20; i++) {
    if(i%2===0){
    console.log(i);
    }
}
